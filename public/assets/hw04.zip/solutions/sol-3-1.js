// #code
// 练习 3 参考答案：多个监听器对比

const btn = document.querySelector('#testBtn');

// onclick：第二次赋值覆盖第一次
btn.onclick = () => console.log('First');
btn.onclick = () => console.log('Second');

// addEventListener：两个处理器都会执行
btn.addEventListener('click', () => console.log('Third'));
btn.addEventListener('click', () => console.log('Fourth'));
