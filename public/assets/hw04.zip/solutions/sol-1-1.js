// #code
// 练习 1 参考答案：基础事件绑定

const btn = document.querySelector('#greetBtn');

btn.addEventListener('click', () => {
  console.log("Hello World");
});
