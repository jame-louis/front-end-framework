// #code
// 练习 2 参考答案：使用 Event 对象

const btn = document.querySelector('#posBtn');

btn.addEventListener('click', (e) => {
  console.log(`点击位置: x=${e.clientX}, y=${e.clientY}`);
});
