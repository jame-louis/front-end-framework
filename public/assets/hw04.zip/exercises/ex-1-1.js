// #code
// 练习 1：基础事件绑定
// 目标：为按钮绑定点击事件，点击后在控制台输出 "Hello World"

// 1. 获取按钮元素
// TODO: 使用 querySelector 获取 id 为 greetBtn 的按钮
const btn = ________________;

// 2. 添加点击事件监听器
// TODO: 使用 addEventListener 绑定 click 事件
// 回调函数中 console.log("Hello World")
________________;
