// #code
// 练习 2：使用 Event 对象
// 目标：点击按钮时，显示鼠标点击位置的坐标

const btn = document.querySelector('#posBtn');

// TODO: 添加 click 事件监听器
// 在回调中，使用 e.clientX 和 e.clientY 获取坐标
// 输出格式："点击位置: x=100, y=200"

