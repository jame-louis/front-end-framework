// #code
// 练习 3：多个监听器对比
// 目标：验证 onclick 和 addEventListener 的区别

const btn = document.querySelector('#testBtn');

// TODO 1: 使用 onclick 绑定两个处理器：分别输出 "First" 和 "Second"


// TODO 2: 使用 addEventListener 绑定两个处理器：分别输出 "Third" 和 "Fourth"


// 预期结果：
// - 先输出 "Second"（onclick 只保留最后一个）
// - 然后输出 "Third" 和 "Fourth"（addEventListener 两个都执行）
